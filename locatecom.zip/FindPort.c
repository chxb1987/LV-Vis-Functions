#include <ansi_c.h>
#include "locatecom.h"

main()
{
	int portlist[255];
	int nPorts, indx;
	
	// (1) - See if a particular port exists and is available
	int com4Exists = (4 == LocateCom("COM4",NULL,0));
	
	printf("COM4 %s\n",com4Exists?"exists":"does not exist");
	
	// (2) - Enumerate all available ports
	nPorts=LocateCom("",portlist,255);
	if (nPorts)
	{
		for (indx=0;indx<nPorts;indx++)
			printf("Port %d is %d\n",indx+1,portlist[indx]);
	}
	getchar();
}
